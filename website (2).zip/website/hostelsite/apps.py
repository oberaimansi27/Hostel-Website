from django.apps import AppConfig


class HostelsiteConfig(AppConfig):
    name = 'hostelsite'
