from django import forms

class ComplaintForm(forms.Form):
	name = forms.CharField(max_length=200)
	sub=forms.CharField(max_length=1000)
	msg=forms.CharField(max_length=5000)
	sch=forms.CharField(max_length=9)
	email=forms.CharField(max_length=500)
	
class MessmenuForm(forms.Form):
	picture = forms.ImageField()