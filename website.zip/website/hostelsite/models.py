from django.db import models

# Create your models here.
class Complaints(models.Model):
	name=models.CharField(max_length=200)
	sub=models.CharField(max_length=1000)
	msg=models.CharField(max_length=5000)
	
	class Meta:
		db_table='complaints'
		
class MessMenu(models.Model):
	picture = models.ImageField(upload_to = 'menu_pictures',blank=True)
	class Meta:
		db_table = "messmenu"