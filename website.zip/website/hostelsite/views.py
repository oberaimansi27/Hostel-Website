from django.shortcuts import render
from django.http import HttpResponse
from hostelsite.forms import *
from hostelsite.models import *

def complaintssubmit(request):
	name="not send"
	if request.method=="POST":
		form= ComplaintForm(request.POST)
		
		if form.is_valid():
			name= request.POST['name']
			sub= request.POST['sub']
			msg=request.POST['msg']
			obj= Complaints(name=name, sub=sub, msg= msg)
			obj.save()
			
			return render(request, 'complaints.html', {'form':form})
	else:
		form= ComplaintForm()
		
	return render(request, 'complaints.html', {'form':form})

def showcomplaints(request):
	Objects= Complaints.objects.all()
	res='DB entry: <br>'

	for elt in Objects:
		res += 'NAME:' +elt.name+'<br> SUBJECT: '+ elt.sub+'<br> Complain:' + elt.msg +'<br>'
	return HttpResponse(res)



def SaveMenu(request):
   saved = False
   MessMenu.objects.all().delete()
   if request.method == "POST":
      #Get the posted form
      MyForm = MessmenuForm(request.POST, request.FILES)
      
      if MyForm.is_valid():
         menu= MessMenu()
         menu.picture = MyForm.cleaned_data["picture"]
         menu.save()
         saved = True
   else:
      MyForm = MessmenuForm()
		
   return render(request, 'saved.html', locals())
   

	
	